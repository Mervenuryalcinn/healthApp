from flask import Flask, request, jsonify
from flask_cors import CORS
import jwt
from functools import wraps
import pandas as pd
import numpy as np
import joblib  # model ve scaler için

app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = 'health-app-secret-key-2023'

users = []

# ========================
# Model, scaler ve label encoders yükle
# ========================
try:
    diabetes_model = joblib.load("model.pkl")  # Colab'dan indirdiğin model
    scaler = joblib.load("scaler.pkl")        # Colab'dan indirdiğin scaler
    # label_encoders = joblib.load("label_encoders.pkl")  # eğer kaydettiysen
    print("✅ Diyabet modeli başarıyla yüklendi")
except Exception as e:
    print(f"❌ Model yükleme hatası: {e}")
    print("⚠️ Basit kural tabanlı sistem kullanılacak")
    diabetes_model, scaler, label_encoders = None, None, None

# ========================
# Token kontrol fonksiyonu
# ========================
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'success': False, 'error': 'Token is missing!'}), 401
        try:
            if token.startswith('Bearer '):
                token = token[7:]
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = next((user for user in users if user['email'] == data['email']), None)
        except Exception as e:
            return jsonify({'success': False, 'error': f'Token is invalid! {str(e)}'}), 401
        return f(current_user, *args, **kwargs)
    return decorated

# ========================
# Basit risk hesaplama
# ========================
def calculate_risk_simple(glucose_level):
    if glucose_level > 140:
        return "YÜKSEK", "red", "Yüksek şeker seviyesi. Doktorunuza danışmanız önerilir."
    elif glucose_level >= 100:
        return "ORTA", "orange", "Sınırda şeker seviyesi. Diyetinize dikkat etmelisiniz."
    else:
        return "DÜŞÜK", "green", "Normal şeker seviyesi. Sağlıklı beslenmeye devam edin."

# ========================
# Tahmin endpoint'i
# ========================
@app.route('/predict_diabetes', methods=['POST'])
def predict_diabetes():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'Data is required'})

        glucose_keys = ['blood_glucose_level', 'glucose_level', 'glucose', 'sugar', 'sugar_level', 'value', 'deger', 'kan_sekeri']
        glucose_value = None
        for key in glucose_keys:
            if key in data:
                glucose_value = data[key]
                break
        if glucose_value is None:
            return jsonify({'success': False, 'error': 'Glucose level is required'})

        glucose_level = float(glucose_value)

        if diabetes_model is not None:
            try:
                input_data = []
                for col in ['gender', 'age', 'hypertension', 'heart_disease', 'smoking_history', 'bmi', 'HbA1c_level', 'blood_glucose_level']:
                    val = data.get(col, 0)
                    if label_encoders and col in label_encoders:
                        val = label_encoders[col].transform([val])[0]
                    input_data.append(float(val))

                sample_scaled = scaler.transform([input_data])
                prediction = diabetes_model.predict(sample_scaled)[0]
                probability = diabetes_model.predict_proba(sample_scaled)[0][1]

                risk_level = "YÜKSEK" if prediction == 1 else "DÜŞÜK"
                color = "red" if prediction == 1 else "green"
                recommendation = f"AI Tahmini: Diyabet riski {probability*100:.1f}%"

            except Exception as e:
                print(f"❌ AI model hatası: {e}, basit kurallara geçiliyor")
                risk_level, color, recommendation = calculate_risk_simple(glucose_level)
        else:
            risk_level, color, recommendation = calculate_risk_simple(glucose_level)

        return jsonify({
            'success': True,
            'result': {
                'risk_level': risk_level,
                'color': color,
                'glucose_level': glucose_level,
                'model_used': 'ai' if diabetes_model is not None else 'simple'
            },
            'recommendations': [recommendation]
        })

    except Exception as e:
        return jsonify({'success': False, 'error': f'Hesaplama hatası: {str(e)}'})

# ========================
# Sunucuyu başlat
# ========================
if __name__ == '__main__':
    print("🚀 Flask sunucusu başlatılıyor...")
    print("📊 Diyabet modeli durumu:", "Hazır" if diabetes_model is not None else "Basit mod")
    print("🌐 Sunucu adresi: http://127.0.0.1:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)
